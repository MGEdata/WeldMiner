"""WeldMiner extraction components."""
