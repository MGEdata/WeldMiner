"""WeldMiner llm components."""
