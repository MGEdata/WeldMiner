"""WeldMiner models components."""
